@echo off
setlocal
cd /d "%~dp0"

if not exist lib mkdir lib
if not exist lib\mysql-connector-j.jar (
    echo Descargando MySQL Connector/J...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/9.4.0/mysql-connector-j-9.4.0.jar' -OutFile 'lib\mysql-connector-j.jar'"
    if errorlevel 1 (
        echo No se pudo descargar el conector de MySQL.
        pause
        exit /b 1
    )
)

if exist bin rmdir /s /q bin
mkdir bin

echo Compilando...
javac -encoding UTF-8 -cp "lib\mysql-connector-j.jar" -d bin src\dao\*.java src\excepciones\*.java src\interfaces\*.java src\modelo\*.java src\service\*.java src\main\*.java

if errorlevel 1 (
    echo Error de compilacion.
    pause
    exit /b 1
)

echo Ejecutando...
java -cp "bin;lib\mysql-connector-j.jar" main.Main

pause
