package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {

    private static final String SERVIDOR = "jdbc:mysql://localhost:3306/?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String URL = "jdbc:mysql://localhost:3306/buffet?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USUARIO = "root";
    private static final String CLAVE = "";

    public static Connection obtenerConexion() throws SQLException {
        try (Connection con = DriverManager.getConnection(SERVIDOR, USUARIO, CLAVE);
             Statement st = con.createStatement()) {
            st.executeUpdate("CREATE DATABASE IF NOT EXISTS buffet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }

        Connection con = DriverManager.getConnection(URL, USUARIO, CLAVE);
        try (Statement st = con.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS entidades ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT,"
                    + "nombre VARCHAR(50) NOT NULL,"
                    + "tipo VARCHAR(30) NOT NULL,"
                    + "dia_actual INT,"
                    + "tareas_completadas INT,"
                    + "dinero INT,"
                    + "dialogo VARCHAR(255),"
                    + "rol VARCHAR(50),"
                    + "pedido VARCHAR(100),"
                    + "atendido BOOLEAN,"
                    + "tipo_objeto VARCHAR(50),"
                    + "utilizable BOOLEAN,"
                    + "cantidad INT,"
                    + "descripcion VARCHAR(255),"
                    + "tipo_tarea VARCHAR(50),"
                    + "completada BOOLEAN,"
                    + "dia INT"
                    + ")");
        } catch (SQLException e) {
            con.close();
            throw e;
        }
        return con;
    }
}
